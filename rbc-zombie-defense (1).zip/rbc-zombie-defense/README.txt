RBC DEFENSE - Sickle Cell Nursing Arcade

HOW TO PLAY ON LAPTOP
1. Extract this ZIP file.
2. Double-click index.html to open it in Chrome or Edge.
3. Click START GAME (this unlocks audio in the browser).
4. Use Arrow Left / Right or A / D to move; Space to fire; P to pause.
5. Shoot five sickle-shaped enemies, then answer the MCQ correctly to unlock the next stage.
6. Music and SFX can be turned on/off at the top.

HOW TO PUBLISH TO GITHUB PAGES
1. Create a PUBLIC GitHub repository, e.g. rbc-zombie-defense.
2. Upload index.html to the root of the default main branch.
3. Visit Settings > Pages > Deploy from a branch > main > /(root), then Save.
4. Your eventual URL will be https://YOUR-USERNAME.github.io/rbc-zombie-defense/

The game includes 10 original MCQs on sickle cell anaemia based on the earlier learning set.
The original background music is synthesised locally via Web Audio API.
Saved progress uses localStorage, so it only persists in the same browser and device.
Clinical teaching questions should be reviewed by an instructor before assessed use.
